package com.seneca.students;

public interface OnItemClickListener {
    void onItemClick(int position);
}
